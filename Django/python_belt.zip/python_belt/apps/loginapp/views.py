from django.shortcuts import render,redirect, HttpResponse
from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages
from django.db import models
   
from .models import *

# Create your views here.

def index(request):
    if 'banner' not in request.session:
        request.session['banner'] = 'Please fill the form to register!'
    return render(request,"loginapp/index.html")

def register(request):
    
    errors = Users.objects.basic_validator(request.POST)
    if len(errors):
        for key, value in errors.items():
            messages.error(request, value)
        
        return redirect('/')
    else:
        Users.objects.create(first_name=request.POST['first_name'], last_name=request.POST['last_name'], email=request.POST['email'], password=request.POST['password'])
        request.session['banner'] = 'Thanks for registering'
        return redirect('/')

    
def login(request):
    var1 = Users.objects.get(email=request.POST['email'])
    if var1.password == request.POST['password']:
        request.session['userid'] = var1.id
        request.session['name'] = var1.first_name
        request.session['loggedin'] = True
        return redirect('/quotes')
    else:
        if 'loggedin' not in request.session:
            request.session['loggedin'] = False
        return redirect('/')
    

def quotes(request):
    if 'loggedin' not in request.session:
        request.session['loggedin'] = False
    if request.session['loggedin'] == True:
        context = {
            'quotes': Quotes.objects.all(),
            'users' : Users.objects.all(),
        }
        return render(request, 'loginapp/quotes.html', context)
    else:
        return redirect('/')

def logout(request):
    request.session['loggedin'] = False
    return redirect('/')


#Add Quote
def add_quote(request):
    #errors = Quotes.objects.quote_validator(request.POST)
    #if len(errors):
    #     for key, value in errors.items():
    #         messages.error(request, value)
    #         print(errors)
        
    #     return redirect('/quotes')
    #else:
    Quotes.objects.create(author=request.POST['author'], quote_text=request.POST['user_quote'], uploader=Users.objects.get(id=request.session['userid']))
    # print(request.POST['author'])
    # print(request.POST['user_quote'])
    return redirect('/quotes')

#Show User Quotes
def showuser(request):
    if 'loggedin' not in request.session:
        request.session['loggedin'] = False
    if request.session['loggedin'] == True:
    # context = {
    #     'id' : id,
    #     'users' : Users.objects.get(id=id))
    # }
        return render(request, 'loginapp/showuser.html')
    else:
        return redirect('/')

#Edit Page
def edituser(request):
    if 'loggedin' not in request.session:
        request.session['loggedin'] = False
    if request.session['loggedin'] == True:
        return render(request, "loginapp/edituser.html")
    else:
        return redirect('/')


#Delete Page 
def delete(request):
    context = {
        'quote': Quotes.objects.all(),
    }
    deleteQuote = Quotes.objects.get(id=quote.id).delete()

    return redirect('/quotes')