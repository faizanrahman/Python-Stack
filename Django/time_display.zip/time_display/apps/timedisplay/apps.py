from django.apps import AppConfig


class TimedisplayConfig(AppConfig):
    name = 'timedisplay'
