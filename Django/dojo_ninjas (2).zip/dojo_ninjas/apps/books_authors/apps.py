from django.apps import AppConfig


class BooksAuthorsConfig(AppConfig):
    name = 'books_authors'
