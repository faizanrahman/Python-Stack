from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)
#Set a secret key to use sessions.
app.secret_key='1234'

@app.route('/',methods=['GET', 'POST'])
def visits():
    if 'visits' in session:
        session['visits'] = session.get('visits') + 1 #reading and updating data in sessions if session exists
    else:
        session['visits'] = 1  # setting session data
    print(session['visits'])
    #session['visits'] = 0;
    #whenever a page reloads, increment session['visits'] by 1.
    if 'increment' in request.form:
        session['visits'] +=1
    if 'reset' in request.form:
       session['visits'] = 1
       #session.clear()

    return render_template('index.html')

@app.route('/destroy_session')
def resetSession():
    session.clear()
    #print(session['visits'])
    return redirect('/') 

@app.route('/increment')
def increment():
    session['visits'] +=1
    return redirect('/')





if __name__=="__main__":
    app.run(debug=True)